a=10
b=10
c=a+b
print("a+b")
print("Sum of a+b")
print(c)