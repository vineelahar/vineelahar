def great(n):
    if n > 0:
        print("hello, Welcome to python")
        great(n-1)

# Call the function
great(5)
