#d = {"name":"alice","age":25,"city":"newyork"}
#print(d.items())
#print(d.values())
#print(d.keys())
#print(d.get(1))
#d["city"] = "Los Angeles" (update)
#print(d)
#d["email"] = "alice@gmail.com"  (add)
#print(d)
#del d["age"] (delete)
#print(d)


#text = "hello"

# Create an empty dictionary
#i_count = {}

# Loop through each letter in the string
#for i in text:
    #3if  i in i_count:
      #  i_count[i] += 1
    #else:
     #   i_count[i] = 1

# Print the dictionary
#print(i_count)


#d1 = {'a':1}
#d2 = {'b':2}
#merged_d3 = {**d1, **d2}
#print(merged_d3)

#person = {
 #   "Name": "Alice",
  #  "Age": 25,
   # "City": "Los Angeles"
#}

# Key to check
#key_to_check = "Age"

# Checking if key exists
#if key_to_check in person:
 #   print(f"Key '{key_to_check}' exists in the dictionary.")
#else:
 #   print(f"Key '{key_to_check}' does NOT exist in the dictionary.")


#squares = {}
# Loop through numbers 1 to 5
#for num in range(1, 6):
 #   squares[num] = num ** 2
# Print the dictionary
#print(squares)

  