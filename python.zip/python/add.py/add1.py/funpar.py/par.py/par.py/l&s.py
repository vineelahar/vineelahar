x=10 #local variables
def my_function():
    x=10 #local variables
    x=5 #globel variables
    print("local variables")
    my_function()
print("globel variables")