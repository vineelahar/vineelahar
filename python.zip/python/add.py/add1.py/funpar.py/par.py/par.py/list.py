#my_list = [1,2,3,4]
#reversed_list = my_list[::-1]
#print("Reversed list",reversed_list)


#largest and smallest
#my_list = [2,5,1,3]
#max_value = max(my_list)
#min_value = min(my_list)
#print("max number of the list",max_value)
#print("min number of the lilst",min_value)

# length of elments in the list
#my_list = [1,2,3,4]
#length = len(my_list)
#print("length of the list:",length)
#print("list:",my_list)


# sum of the elements in thde list
#my_list = [1,2,3,4]
#total = sum(my_list)
#print("sum of the elements:",total)

# 2nd largest enement of the list
my_list = [10,20,4,45,99]
my_list.sort()  # sorts the list in ascending order
second_largest = my_list[3]  # second last element
print("Second largest element is:", second_largest)