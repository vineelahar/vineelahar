#def add(a, b):
#   return a + b

#a = 5
#b = 3
#result = add(a, b)
#print("a =", a)
#print("b =", b)
#print("Result:", result)

#positional argunments
#def full_name(first, last):
#    print(f"Full Name: {first} {last}")

# Call the function
#full_name("vineela", "reddy")

#default argunments
#def greet(name="guest"):
#    print(f"Hello, {name}!")

# Calling the function with and without arguments
#greet()  # Uses the default argument "guest"
#greet("vineela")  # Passes "vineela" as the argument

#key argunments
#def student_details(name,age,course):
#    print(f"{name},age={age},course={course}")
#    student_details(age=22, name="harish", course="cs")

#def student_details(name, age, course):
#    print(f"{name}, age={age}, course={course}")
# Call the function with specific arguments
#student_details(age=22, name="Harish", course="CS")

#arbitraty argunments
#def sum_numbers(*numbers):
#    total = sum(numbers)
#    print(total)
#sum_numbers(1,100)

#returning values
#def square(num):
#    return num*num
#print(square(1000))

#returning multiple values
def calculate(a,b):
    return a+b,a-b,a*b,a/b
print(calculate(5,2))