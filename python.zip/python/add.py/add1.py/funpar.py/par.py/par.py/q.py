#a = '3'
#b = int(a)+5
#print(b)


x = "1"
y = "2" 
add = x+y
print("add")