#string = input("enter a string")   (REVERSED STRING)
#reversed_string = string[::-1]
#print("Reversed string",reversed_string)

str_1 =input("enter a string")
print(str_1[::-1])
if str_1 ==  str_1[::-1]:
    print("this is palindrome")
else:
      print("this is not a palindrome")