a=5
print("The type of a",type(a))
b=0.5
print("The type of b",type(b))
c=2+3j
print("the type of c",type(c))