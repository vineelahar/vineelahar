#fruits = {"apple","mango","banana"}
#for fruit in fruits:
    #print("fruits")


#fruits = ["apple", "banana", "cherry"]
#for fruit in fruits:
   # print(fruit)

#for i in range(10):
    #print(i)


#numbers = [1, 2, 3, 4, 5]
#for num in numbers:
 #   if num == 3:
  #      break
   # print(num)

#numbers = {1,2,3,4,5,6,7,8,}
#for num in numbers:
#  if num == 3:
#     continue
# print(num)


#numbers = {1,2,3,4,5,6,7,8,9}
#for num in numbers:
#   if num == 3:
#        pass
#    print(num)
        

numbers = {1,2,10,12,13,14,5,6,7,87,77,76}
square =0
squares =[]
for values in numbers:
    square = values**2
    print(" the list of squares is",square)
