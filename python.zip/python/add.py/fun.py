#def gree ():
#   print ("str")
#  return
#print("I am the first call to the user defined function")
#print("I am second call to the same  function")

# functions with parameters
#def add(a,b):
#   return a,b,a+b,a*b
#result = add(5,3)
#print(result)
   

#function argumentss
S = "Hello,python"
print(len(S))