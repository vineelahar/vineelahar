# x =10
#if x > 5:
    #print("x is greaterthan 5")




a=int(input("enter a"))
b=int(input("enter b"))
c=int(input("enter c"))
if a>b and a>c:
    print("from above three numbers a is largest")
    if b>a and b>c:
        print("from the above three numbers b is largest")
        if c>a and c>b:
            print("from the above three numbers c is largest")
