num= int(input("enter the number"))
if num ==10:
    print("the given nuumber is equal to 10")
elif num ==50:
    print("enter the given num is equql to 50")
elif num==100:
    print ("enter the given num  is equal to 100")
else:
     60
    print("the given num is not equal to 10,50 & 100")
  
     

