list = [1,"hi","python",2]
print(list)
print(list*2)
#list slicing
print(list)
print(list+list)
