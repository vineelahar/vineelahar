set1 = set()
set2 ={'hi',1,2,'python'}
print("set2")
#Adding the element in the set
set2.add(10)
print("After adding 10",set2)
set2.remove(2)
print("After remove 2",set2)

