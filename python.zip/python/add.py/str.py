str1 = 'vineela'
str2 = 'hlo welcome'
print(str1[2])
print(str2[4])
print(str1*2)
print(str1+str2)
