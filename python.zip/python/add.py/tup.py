tup = [1, 'hi', 'python', 2]
print(tup)
print(tup+tup)
print(tup*3)
print(tup[2])