#counter= 0
#while counter < 10:
#   counter = counter+3
#   print(counter)

#i=1
#while i <=5:
#   print(i)
#    i+=1

i=1
while i <=5:
    print(i)
    if i == 3:
        break
    i+=1
